from django.shortcuts import render
from rest_framework.views import APIView,View
from rest_framework.response import Response
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .utils import filter, convertjson, getuniques, uniquecounter
import json
# Create your views here.

class DashBoard(APIView):
    def get(self,request,*args,**kwargs):
        return render(request,template_name='index.html')
dashboard = DashBoard.as_view()



@method_decorator(csrf_exempt, name='dispatch')
class GetDashboardData(View):
    def post(self,request,*args,**kwargs):
        try:
            fdata= json.loads(request.body.decode('utf-8'))
        except:

            fdata={}
        page_name = 'full_data'
        data,endpoints = filter(fdata,page_name) #filter and convet to json file
        print(endpoints)
        results,selected_entity=convertjson(endpoints) #convert in to json identify the displayable entty
        print(selected_entity,">>>>>")
        counts,time = uniquecounter(results,selected_entity)
        return JsonResponse({'tiem':time,'DataSize':len(results),'QualifiedEntity':selected_entity,'ChartData':counts,'TableData':results})



    def get(self,request,*args,**kwargs):
        results = getuniques()
        return JsonResponse({'data':results})

get_dashboard_data = GetDashboardData.as_view()


@method_decorator(csrf_exempt, name='dispatch')
class GetOptimizedData(View):
    def post(self,request,*args,**kwargs):
        try:
            fdata= json.loads(request.body.decode('utf-8'))
        except:

            fdata={}
        page_name ='opt_data'
        data,endpoints = filter(fdata,page_name) #filter and convet to json file
        print(endpoints)
        results,selected_entity=convertjson(endpoints) #convert in to json identify the displayable entty
        print(selected_entity,">>>>>")
        counts,time = uniquecounter(results,selected_entity)
        return JsonResponse({'tiem':time,'DataSize':len(results),'QualifiedEntity':selected_entity,'ChartData':counts,'TableData':results})



    def get(self,request,*args,**kwargs):
        results = getuniques()
        return JsonResponse({'data':results})

get_optimized_data = GetOptimizedData.as_view()




@method_decorator(csrf_exempt, name='dispatch')
class DifferencetData(View):
    def post(self,request,*args,**kwargs):
        try:
            fdata= json.loads(request.body.decode('utf-8'))
        except:

            fdata={}
        page_name ='diff_data'
        data,endpoints = filter(fdata,page_name) #filter and convet to json file
        print(endpoints)
        results,selected_entity=convertjson(endpoints) #convert in to json identify the displayable entty

        return JsonResponse({'data':results,'DataSize':len(results)})




get_difference_data = DifferencetData.as_view()





@method_decorator(csrf_exempt, name='dispatch')
class GenerateInputData(View):
    def post(self,request,*args,**kwargs):
        try:
            fdata= json.loads(request.body.decode('utf-8'))
        except:
            return JsonResponse({'data': False})

        requirements = fdata['new_requirements']
        c1 = fdata['C1']
        c2 = fdata['C2']
        c3 = fdata['C3']
        keyword = fdata['keyword']
        # here call yor model
        print(fdata,"inputdata input data")

        return JsonResponse({'data':True})

get_input_data = GenerateInputData.as_view()