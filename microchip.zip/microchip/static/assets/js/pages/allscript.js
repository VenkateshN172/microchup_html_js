// A $( document ).ready() block.
function CallInitailaldata(){

$.ajax({
    url : "/get-data",
    type: "Get",
       success: function(data, textStatus, jqXHR)
    {

        FillDropHtmlOptions(data)
    },
    error: function (jqXHR, textStatus, errorThrown)
    {

    }
});



}

function FillDropHtmlOptions(data){
$('#Selection_options').empty()
$('#Complexity_options').empty()
$('#Priority_options').empty()
$('#Selection_options').append('<option value="" selected >Select</option>')
$('#Complexity_options').append('<option value="" selected >Select</option>')
$('#Priority_options').append('<option value="" selected >Select</option>')

    for(var i=0;i<data['data'][0]['Section'].length;i++){
     $('#Selection_options').append("<option value="+data['data'][0]['Section'][i]+">"+data['data'][0]['Section'][i]+"</option>")
    }

    for(var i=0;i<data['data'][1]['Complexity'].length;i++){
     $('#Complexity_options').append("<option value="+data['data'][1]['Complexity'][i]+">"+data['data'][1]['Complexity'][i]+"</option>")
    }

    for(var i=0;i<data['data'][2]['Priority'].length;i++){
     $('#Priority_options').append("<option value="+data['data'][2]['Priority'][i]+">"+data['data'][2]['Priority'][i]+"</option>")
    }

}


$( document ).ready(function() {
    CallInitailaldata()
    PostData({})




});


function PostData(formData){

$.ajax({
    url : "/get-data",
    type: "POST",
    data : formData,
       success: function(data, textStatus, jqXHR)
            {
                GenerateChartTest(data['ChartData'])
                GeneratePredTimeChart(data['tiem'])
                GenratepredTabledata(data['TableData'])
                $('#total_no_test').text(data['DataSize'])
            },
    error: function (jqXHR, textStatus, errorThrown)
            {

            }

})

    $.ajax({
    url : "/get-optimized-data",
    type: "POST",
    data : formData,
       success: function(data, textStatus, jqXHR)
            {
                GenerateOptimizedChartTest(data['ChartData'])
                GenerateoptimizedTimeChart(data['tiem'])
                GenrateOptimizedTabledata(data['TableData'])
                $('#opt_total_no_test').text(data['DataSize'])
            },
    error: function (jqXHR, textStatus, errorThrown)
            {

            }

})

    $.ajax({
    url : "/get-difference-data",
    type: "POST",
    data : formData,
       success: function(data, textStatus, jqXHR)
            {
             GenrateDifferenceTabledata(data['data'])

            },
    error: function (jqXHR, textStatus, errorThrown)
            {

            }

})


}






$("#GetChartData").click(function(){
    var formData = {}
    if($('#Selection_options').val()){

        formData['section']=$('#Selection_options option:selected').text()

    }
    if($('#Complexity_options').val()){

        formData['complexity']=$('#Complexity_options option:selected').text()

    }
    if($('#Priority_options').val()){

        formData['priority']=$('#Priority_options option:selected').text()

    }


    PostData(JSON.stringify(formData))

});







function GenerateChartTest(ChartData){
    $('#stacked-column-chart').empty()
    var xaxix = []
    var yaxix = []
    for(k in ChartData){
        xaxix.push(ChartData[k])
        yaxix.push(k)
    }
var options = {
    chart: {
        height: 200,
        type: "bar",
        stacked: !0,
        toolbar: {
            show: !0
        },
        zoom: {
            enabled: !0
        }
    },
    plotOptions: {
        bar: {
            horizontal: !1,
            columnWidth: "15%",
            endingShape: "rounded"
        }
    },
    dataLabels: {
        enabled: !1
    },
    series: [{
        name: "Series A",
        data: xaxix
    }],
    xaxis: {
        categories: yaxix
    },
    colors: ["#d623c8"],
    legend: {
        position: "bottom"
    },
    fill: {
        opacity: 1
    }
};
var chartr = new ApexCharts(document.querySelector("#stacked-column-chart"), options)
chartr.render();


}


function GeneratePredTimeChart(ChartData){

    $('#stacked-column-chart2').empty()
    var xaxix = []
    var yaxix = []
    var total_time =0
    for(k in ChartData){
        total_time+=ChartData[k]
        xaxix.push(ChartData[k])
        yaxix.push(k)
    }
    var options = {
        chart: {
            height: 200,
            type: "bar",
            stacked: !0,
            toolbar: {
                show: !0
            },
            zoom: {
                enabled: !0
            }
        },
        plotOptions: {
            bar: {
                horizontal: !1,
                columnWidth: "15%",
                endingShape: "rounded"
            }
        },
        dataLabels: {
            enabled: !1
        },
        series: [{
            name: "mins",
            data: xaxix
        }],
        xaxis: {
            categories: yaxix
        },
        colors: ["#fab256"],
        legend: {
            position: "bottom"
        },
        fill: {
            opacity: 1
        }
    };
    var chartr = new ApexCharts(document.querySelector("#stacked-column-chart2"), options)
    chartr.render();


    total_time =total_time/60
    console.log(total_time,">>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<")
    $('#pred_total_time').text(total_time.toFixed(2))
    var pred_person_days = total_time/8
    $('#pred_person_days').text(pred_person_days.toFixed(2))
}

//optimzeed time
function GenerateOptimizedChartTest(ChartData){
    $('#stacked-column-chart_o').empty()
    var xaxix = []
    var yaxix = []
    for(k in ChartData){
        xaxix.push(ChartData[k])
        yaxix.push(k)
    }
var options = {
    chart: {
        height: 200,
        type: "bar",
        stacked: !0,
        toolbar: {
            show: !0
        },
        zoom: {
            enabled: !0
        }
    },
    plotOptions: {
        bar: {
            horizontal: !1,
            columnWidth: "15%",
            endingShape: "rounded"
        }
    },
    dataLabels: {
        enabled: !1
    },
    series: [{
        name: "Series A",
        data: xaxix
    }],
    xaxis: {
        categories: yaxix
    },
    colors: ["#2323d6"],
    legend: {
        position: "bottom"
    },
    fill: {
        opacity: 1
    }
};
var chartr = new ApexCharts(document.querySelector("#stacked-column-chart_o"), options)
chartr.render();
}



function GenerateoptimizedTimeChart(ChartData){

    $('#stacked-column-chart2_o').empty()
    var total_time =0
    var xaxix = []
    var yaxix = []
    var total_time =0
    for(k in ChartData){
        total_time+=ChartData[k]
        xaxix.push(ChartData[k])
        yaxix.push(k)
    }
    var options = {
        chart: {
            height: 200,
            type: "bar",
            stacked: !0,
            toolbar: {
                show: !0
            },
            zoom: {
                enabled: !0
            }
        },
        plotOptions: {
            bar: {
                horizontal: !1,
                columnWidth: "15%",
                endingShape: "rounded"
            }
        },
        dataLabels: {
            enabled: !1
        },
        series: [{
            name: "mins",
            data: xaxix
        }],
        xaxis: {
            categories: yaxix
        },
        colors: ["#23b5d6"],
        legend: {
            position: "bottom"
        },
        fill: {
            opacity: 1
        }
    };
    var chartr = new ApexCharts(document.querySelector("#stacked-column-chart2_o"), options)
    chartr.render();
    total_time =total_time/60
    console.log(total_time,">>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<")
    $('#opt_total_time').text(total_time.toFixed(2))
    var pred_person_days = total_time/8
    $('#opt_person_days').text(pred_person_days.toFixed(2))




}



function GenratepredTabledata(data){

    var str=''
     $('#predicted_table_data').empty()
    for(i=0;i<data.length;i++){

    str += '<tr><td>'+data[i]['Case ID']+'</td><td>'+data[i]['Complexity']+'</td><td>'+data[i]['Defects']+'</td><td>'+data[i]['Estimate(in Mins)']+'</td><td>'+data[i]['Expected Result']+'</td><td>'+data[i]['Keyword']+'</td><td>'+data[i]['Priority']+'</td><td>'+data[i]['Keyword']+'</td><td>'+data[i]['Regression']+'</td><td>'+data[i]['Section']+'</td><td>'+data[i]['Test_Title']+'</td><td>'+data[i]['input_desc']+'</td><td></tr>'


    }
    $('#predicted_table_data').html(str)

}



function GenrateOptimizedTabledata(data){

    var str=''
     $('#optimized_table_data').empty()
    for(i=0;i<data.length;i++){

    str += '<tr><td>'+data[i]['Case ID']+'</td><td>'+data[i]['Complexity']+'</td><td>'+data[i]['Defects']+'</td><td>'+data[i]['Estimate(in Mins)']+'</td><td>'+data[i]['Expected Result']+'</td><td>'+data[i]['Keyword']+'</td><td>'+data[i]['Priority']+'</td><td>'+data[i]['Keyword']+'</td><td>'+data[i]['Regression']+'</td><td>'+data[i]['Section']+'</td><td>'+data[i]['Test_Title']+'</td><td>'+data[i]['input_desc']+'</td><td></tr>'


    }
    $('#optimized_table_data').html(str)


}

function GenrateDifferenceTabledata(data){

    var str=''
     $('#difference_table_data').empty()
    for(i=0;i<data.length;i++){

    str += '<tr><td>'+data[i]['Case ID']+'</td><td>'+data[i]['Complexity']+'</td><td>'+data[i]['Defects']+'</td><td>'+data[i]['Estimate(in Mins)']+'</td><td>'+data[i]['Expected Result']+'</td><td>'+data[i]['Keyword']+'</td><td>'+data[i]['Priority']+'</td><td>'+data[i]['Keyword']+'</td><td>'+data[i]['Regression']+'</td><td>'+data[i]['Section']+'</td><td>'+data[i]['Test_Title']+'</td><td>'+data[i]['input_desc']+'</td><td></tr>'


    }
    $('#difference_table_data').html(str)


}


function PostInputData(){


        var result = { };
        var data = $('#inputdataform').serializeArray()
        console.log(data,">>>>")
        for(k in data){

            result[data[k]['name']]=data[k]['value']
        }
        console.log(result,"resultresultresultresultresult")

        $.ajax({
            url : "/get-input-data",
            type: "Post",
            data:result,
               success: function(data, textStatus, jqXHR)
            {
                $('#input_screen').modal('hide')
                alert('sucessfully posted')
                window.location.reload()
            },
            error: function (jqXHR, textStatus, errorThrown)
            {

            }
        });

}



//
//ChartData={C2: 16, C1: 5, C3: 2}
//var xaxix = []
//var yaxix = []
//for(k in ChartData){
//xaxix.push(ChartData[k])
//yaxix.push(k)
//}